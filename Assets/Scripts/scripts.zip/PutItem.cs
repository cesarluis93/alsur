﻿using UnityEngine;
using System.Collections;

public class PutItem : MonoBehaviour {
	public GameObject item;

	public GameObject getItem(){
		return item;
	}
}
